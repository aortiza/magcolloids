from pint import UnitRegistry
ureg = UnitRegistry()

from magcolloid.simulation import *
from magcolloid.support import *
from magcolloid.parameters import *
